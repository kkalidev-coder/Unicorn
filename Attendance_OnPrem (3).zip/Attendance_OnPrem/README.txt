ATTENDANCE - ON-PREMISES SETUP
1. Install Python 3.8+ (no other packages needed).
2. Edit config.json: passwords for the 5 accounts (role admin = upload/send, viewer = view only), recipients, send_time (11:00), smtp block, leave_file.
3. Double-click start_attendance.bat, open http://<server-ip>:8080 and log in.
4. Upload the CSV/Excel punch log from UTime each day (admin accounts).
LEAVE: keep leave in an Excel/CSV register (see LeaveRegister_Template.xlsx; columns: Employee ID, Employee Name, From Date, To Date, Leave Type, Half Day, Status, Remarks).
Only Status = Approved counts. Point "leave_file" in config.json at the file (e.g. a OneDrive-synced SharePoint library folder; use double backslashes in the path),
or upload it on the Email alerts tab. The e-mail lists "Absent - no leave record" and "On approved leave" with the type.

AUTO-IMPORT: set "punch_folder" in config.json to a folder (e.g. C:\\Attendance\\Punches). Drop the UTime CSV/Excel export there (or have UTime/Power Automate save it there);
the server checks every minute and imports new/changed files automatically. LATENESS: first punch after the 'Late after' time (default 09:00) is listed in the email.
