#!/usr/bin/env python3
"""On-premises Attendance server: SQLite database + web UI + absentee e-mail alerts. Python 3.8+, no extra packages."""
import base64, csv, hmac, io, json, os, re, smtplib, sqlite3, ssl, threading, time, zipfile, datetime as dt
import xml.etree.ElementTree as ET
from email.message import EmailMessage
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
HERE = os.path.dirname(os.path.abspath(__file__))
CFG = json.load(open(os.path.join(HERE, 'config.json'), encoding='utf-8'))
DB = os.path.join(HERE, 'attendance.db'); LOCK = threading.RLock()
def db():
    c = sqlite3.connect(DB, timeout=30); c.row_factory = sqlite3.Row; return c
with db() as c:
    c.executescript("""CREATE TABLE IF NOT EXISTS punches(emp TEXT, ts TEXT, PRIMARY KEY(emp,ts));
    CREATE TABLE IF NOT EXISTS employees(id TEXT PRIMARY KEY, name TEXT);
    CREATE TABLE IF NOT EXISTS leaves(emp_id TEXT, emp_name TEXT, d1 TEXT, d2 TEXT, label TEXT);
    CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY, v TEXT);
    CREATE TABLE IF NOT EXISTS email_log(id INTEGER PRIMARY KEY AUTOINCREMENT, sent_at TEXT, for_date TEXT, n INTEGER, to_addr TEXT, status TEXT);""")


# ---------------- leave register (Excel/CSV) ----------------
NS = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
LEAVE_INFO = {'file': CFG.get('leave_file', ''), 'synced': '', 'count': 0, 'error': ''}
def table(data, name):
    if name.lower().endswith(('.csv', '.txt', '.dat')):
        t = data.decode('utf-8-sig', 'replace'); return list(csv.reader(io.StringIO(t), delimiter='\t' if t.split('\n')[0].count('\t') > 1 else ','))
    z = zipfile.ZipFile(io.BytesIO(data)); ss = []
    if 'xl/sharedStrings.xml' in z.namelist():
        ss = [''.join(t.text or '' for t in si.iter(NS + 't')) for si in ET.fromstring(z.read('xl/sharedStrings.xml')).iter(NS + 'si')]
    sh = sorted(n for n in z.namelist() if re.match(r'xl/worksheets/sheet\d+\.xml$', n))[0]; rows = []
    for r in ET.fromstring(z.read(sh)).iter(NS + 'row'):
        row = []
        for c in r.iter(NS + 'c'):
            col = 0
            for ch in re.match(r'[A-Z]+', c.get('r')).group(): col = col * 26 + ord(ch) - 64
            v = c.find(NS + 'v'); t = c.get('t')
            val = ss[int(v.text)] if t == 's' and v is not None else ''.join(x.text or '' for x in c.iter(NS + 't')) if t == 'inlineStr' else (v.text if v is not None else '')
            row += [''] * (col - 1 - len(row)); row.append(val)
        rows.append(row)
    return rows
def pdate(v):
    v = str(v).strip()
    if re.fullmatch(r'\d+(\.\d+)?', v) and float(v) > 20000: return (dt.date(1899, 12, 30) + dt.timedelta(days=int(float(v)))).isoformat()
    for cand in (v, v[:10]):
        for f in ('%Y-%m-%d', '%d/%m/%Y', '%d-%m-%Y', '%d/%m/%y', '%d-%b-%Y', '%d %b %Y', '%d-%b-%y', '%d %B %Y'):
            try: return dt.datetime.strptime(cand, f).date().isoformat()
            except ValueError: pass
    return None
def label(t, half):
    s = t.lower()
    base = 'Sick leave' if 'sick' in s else 'Vacation' if re.search('vacation|annual|holiday', s) else 'Local leave' if 'local' in s else (t.strip().title() or 'Leave')
    return ('Half-day ' + base[0].lower() + base[1:]) if (half or 'half' in s) else base
def sync_leave(data, name):
    rows = [r for r in table(data, name) if any(str(x).strip() for x in r)]
    hi = next(i for i, r in enumerate(rows[:10]) if sum(bool(re.search('from|start|date|type|name|id', str(x), re.I)) for x in r) >= 3)
    h = [str(x).strip().lower() for x in rows[hi]]
    f = lambda rx: next((i for i, x in enumerate(h) if re.search(rx, x)), -1)
    i_id, i_nm, i_f, i_t, i_ty, i_h, i_st = f(r'\bid\b|emp.*(no|code)|badge'), f('name'), f(r'from|start|^date'), f(r'^to\b|to date|end|until'), f('type|leave'), f('half'), f('status')
    g = lambda r, i: str(r[i]).strip() if 0 <= i < len(r) else ''
    out = []
    for r in rows[hi + 1:]:
        if i_st >= 0 and g(r, i_st) and 'approv' not in g(r, i_st).lower(): continue
        d1 = pdate(g(r, i_f)); d2 = pdate(g(r, i_t)) or d1
        if not d1 or not (g(r, i_id) or g(r, i_nm)): continue
        out.append((g(r, i_id), g(r, i_nm).upper(), d1, d2, label(g(r, i_ty), g(r, i_h).lower() in ('yes', 'y', 'true', '1', 'half'))))
    with LOCK, db() as c:
        c.execute('DELETE FROM leaves'); c.executemany('INSERT INTO leaves VALUES(?,?,?,?,?)', out)
    LEAVE_INFO.update(synced=dt.datetime.now().strftime('%Y-%m-%d %H:%M'), count=len(out), error=''); return len(out)
def refresh_leave():
    p = CFG.get('leave_file')
    if not p: return
    try: sync_leave(open(p, 'rb').read(), p)
    except Exception as e: LEAVE_INFO['error'] = 'Could not read leave file (using last known data): %s' % e

# ---------------- punch files dropped in a folder (CSV / Excel from UTime) ----------------
IMPORT_INFO = {'folder': CFG.get('punch_folder', ''), 'last': '', 'error': ''}; SEEN = {}
def import_punches(data, name):
    rows = [r for r in table(data, name) if any(str(x).strip() for x in r)]
    hi = next((i for i, r in enumerate(rows[:10]) if sum(bool(re.search('id|name|date|time|punch|check', str(x), re.I)) for x in r) >= 2), -1)
    if hi >= 0:
        h = [str(x).strip().lower() for x in rows[hi]]; f = lambda rx: [i for i, x in enumerate(h) if re.search(rx, x)]
        idc = (f(r'(emp|user|staff|badge|card|person).*(id|no|code)|^(id|no\.?|pin)$') or [-1])[0]
        nmc = [i for i in f('name') if not re.search('dept|department', h[i])]
        dtc = [i for i in f('date|time|punch|check|clock') if not re.search('status|type|device|mode', h[i])][:2]
    else: idc, nmc, dtc = 0, [], [1]
    out = []
    for r in rows[hi + 1:]:
        g = lambda i: str(r[i]).strip() if 0 <= i < len(r) else ''
        d = tm = None
        for i in dtc:
            v = g(i)
            if re.fullmatch(r'\d+(\.\d+)?', v):
                n = float(v)
                if n > 20000: d = d or pdate(v)
                sec = round((n % 1) * 86400)
                if n % 1 and not tm: tm = '%02d:%02d:%02d' % (sec // 3600, sec % 3600 // 60, sec % 60)
                continue
            d = d or pdate(v); m = re.search(r'(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(am|pm)?', v, re.I)
            if m and not tm:
                hh = int(m.group(1)); hh = hh % 12 + (12 if m.group(4).lower() == 'pm' else 0) if m.group(4) else hh
                tm = '%02d:%s:%s' % (hh, m.group(2), m.group(3) or '00')
        nm = ' '.join(g(i) for i in nmc if g(i)); emp = (g(idc) if idc >= 0 else '') or nm
        if d and tm and emp: out.append((emp, nm or emp, d + ' ' + tm))
    with LOCK, db() as c:
        b = c.total_changes; c.executemany('INSERT OR IGNORE INTO punches(emp,ts) VALUES(?,?)', [(o[0], o[2]) for o in out]); added = c.total_changes - b
        c.executemany('INSERT INTO employees(id,name) VALUES(?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name WHERE excluded.name<>excluded.id', {(o[0], o[1]) for o in out})
    return len(out), added
def watch():
    p = CFG.get('punch_folder')
    if not p or not os.path.isdir(p): return
    for fn in sorted(os.listdir(p)):
        fp = os.path.join(p, fn)
        if not fn.lower().endswith(('.csv', '.xlsx', '.txt', '.dat')) or fn.startswith('~$'): continue
        try:
            mt = os.path.getmtime(fp)
            if SEEN.get(fp) == mt: continue
            n, a = import_punches(open(fp, 'rb').read(), fn); SEEN[fp] = mt
            IMPORT_INFO.update(last='%s - %s: %d rows, %d new' % (dt.datetime.now().strftime('%Y-%m-%d %H:%M'), fn, n, a), error='')
        except Exception as e: IMPORT_INFO['error'] = 'Could not read %s: %s' % (fn, e)

def absentees(c, d):
    """None = cannot judge (Sunday / no log uploaded for that day); else list of absent employees."""
    if dt.date.fromisoformat(d).weekday() == 6: return None
    if not c.execute("SELECT 1 FROM punches WHERE substr(ts,1,10)=? LIMIT 1", (d,)).fetchone(): return None
    ex = set(map(str, CFG.get('exclude_ids', [])))
    lv = [(r['emp_id'], r['emp_name'], r['label']) for r in c.execute('SELECT * FROM leaves WHERE d1<=? AND d2>=?', (d, d))]
    return [{'id': r['id'], 'name': r['name'], 'reason': next((l[2] for l in lv if (l[0] and l[0] == r['id']) or (l[1] and l[1] == r['name'].upper())), '')}
            for r in c.execute("SELECT id,name FROM employees WHERE id NOT IN (SELECT emp FROM punches WHERE substr(ts,1,10)=?) ORDER BY name", (d,)) if r['id'] not in ex]

def send(d, force=False):
    refresh_leave()
    with LOCK, db() as c:
        ab = absentees(c, d)
        if ab is None: return False, 'No attendance log uploaded for %s (or it is a Sunday) - nothing sent.' % d
        if not force and c.execute("SELECT 1 FROM email_log WHERE for_date=? AND status='sent'", (d,)).fetchone(): return False, 'Already sent for ' + d
        to = CFG['recipients']; s = CFG['smtp']; day = dt.date.fromisoformat(d).strftime('%A %d %B %Y')
        th = (c.execute("SELECT v FROM settings WHERE k='late'").fetchone() or [CFG.get('late_after', '09:00')])[0]
        names = {r['id']: r['name'] for r in c.execute('SELECT id,name FROM employees')}
        onlv = [(r['emp_id'], r['emp_name']) for r in c.execute('SELECT emp_id,emp_name FROM leaves WHERE d1<=? AND d2>=?', (d, d))]
        lim = int(th[:2]) * 60 + int(th[3:5]); lt = []
        for r in c.execute("SELECT emp, MIN(substr(ts,12,5)) t FROM punches WHERE substr(ts,1,10)=? GROUP BY emp ORDER BY t", (d,)):
            mins = int(r['t'][:2]) * 60 + int(r['t'][3:5]) - lim; nm = names.get(r['emp'], r['emp'])
            if mins > 0 and not any(l[0] == r['emp'] or (l[1] and l[1] == nm.upper()) for l in onlv): lt.append({'id': r['emp'], 'name': nm, 'reason': '%s (%d min late)' % (r['t'], mins)})
        un = [r for r in ab if not r['reason']]; lv = [r for r in ab if r['reason']]
        if not ab and not lt: return False, 'Nobody is absent or late on %s - nothing sent.' % d
        m = EmailMessage(); m['From'] = s['from']; m['To'] = ', '.join(to)
        m['Subject'] = CFG.get('subject', 'Attendance {date}').format(date=d, count=len(un), leave=len(lv), late=len(lt))
        L = lambda rs, rsn: '\n'.join('%d. %s (ID %s)%s' % (i + 1, r['name'], r['id'], ' - ' + r['reason'] if rsn else '') for i, r in enumerate(rs)) or '-'
        m.set_content('Attendance - %s\n\nABSENT, NO LEAVE RECORD (%d):\n%s\n\nON APPROVED LEAVE (%d):\n%s\n\nLATE ARRIVALS - first punch after %s (%d):\n%s\n' % (day, len(un), L(un, 0), len(lv), L(lv, 1), th, len(lt), L(lt, 1)))
        def tb(title, rs, col): return '<p><b>%s (%d)</b></p><table border="1" cellpadding="6" style="border-collapse:collapse"><tr><th>#</th><th>Employee</th><th>ID</th>%s</tr>%s</table>' % (title, len(rs), '<th>%s</th>' % col if col else '', ''.join('<tr><td>%d</td><td>%s</td><td>%s</td>%s</tr>' % (i + 1, r['name'], r['id'], '<td>%s</td>' % r['reason'] if col else '') for i, r in enumerate(rs)))
        m.add_alternative('<h3>Attendance - %s</h3>%s%s%s' % (day, tb('Absent - no leave record', un, ''), tb('On approved leave', lv, 'Reason'), tb('Late arrivals - first punch after ' + th, lt, 'First punch')), subtype='html')
        st = 'sent'
        try:
            ctx = ssl.create_default_context(); sec = s.get('security', 'starttls')
            srv = smtplib.SMTP_SSL(s['host'], s['port'], timeout=30, context=ctx) if sec == 'ssl' else smtplib.SMTP(s['host'], s['port'], timeout=30)
            with srv:
                if sec == 'starttls': srv.starttls(context=ctx)
                if s.get('user'): srv.login(s['user'], s['password'])
                srv.send_message(m)
        except Exception as e: st = 'FAILED: %s' % e
        c.execute("INSERT INTO email_log(sent_at,for_date,n,to_addr,status) VALUES(?,?,?,?,?)", (dt.datetime.now().strftime('%Y-%m-%d %H:%M'), d, len(un), ', '.join(to), st))
        return st == 'sent', ('Email sent to %s' % ', '.join(to)) if st == 'sent' else st

def scheduler():
    tried = {}
    while True:
        time.sleep(60); watch(); n = dt.datetime.now(); d = n.strftime('%Y-%m-%d')
        if n.strftime('%H:%M') >= CFG.get('send_time', '10:00') and time.time() - tried.get(d, 0) > 900:
            tried[d] = time.time()
            try: send(d)
            except Exception as e: print('scheduler error:', e)

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def ok(self):
        us = CFG.get('users')
        if not us: self.role = 'admin'; return True
        h = self.headers.get('Authorization', '')
        try:
            u, p = base64.b64decode(h[6:]).decode().split(':', 1)
            for x in us:
                if hmac.compare_digest(x['user'].encode(), u.encode()) and hmac.compare_digest(x['password'].encode(), p.encode()):
                    self.role = x.get('role', 'viewer'); return True
        except Exception: pass
        self.send_response(401); self.send_header('WWW-Authenticate', 'Basic realm="Attendance"'); self.end_headers(); return False
    def adm(self):
        if self.role == 'admin': return True
        self.send_response(403); self.end_headers(); return False
    def out(self, body, ctype='application/json'):
        b = body if isinstance(body, bytes) else json.dumps(body).encode()
        self.send_response(200); self.send_header('Content-Type', ctype); self.send_header('Content-Length', str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        if not self.ok(): return
        p = self.path.split('?')[0]
        if p in ('/', '/index.html', '/xlsx.full.min.js'):
            f = 'index.html' if p != '/xlsx.full.min.js' else 'xlsx.full.min.js'
            return self.out(open(os.path.join(HERE, f), 'rb').read(), 'text/html; charset=utf-8' if f.endswith('html') else 'application/javascript')
        with db() as c:
            if p == '/api/data':
                late = c.execute("SELECT v FROM settings WHERE k='late'").fetchone()
                return self.out({'p': [[r['emp'], r['ts']] for r in c.execute('SELECT emp,ts FROM punches')], 'n': {r['id']: r['name'] for r in c.execute('SELECT id,name FROM employees')}, 'late': late[0] if late else '09:00', 'role': self.role, 'lv': [[r['emp_id'], r['emp_name'], r['d1'], r['d2'], r['label']] for r in c.execute('SELECT * FROM leaves')]})
            if p == '/api/mail':
                return self.out({'recipients': CFG['recipients'], 'send_time': CFG.get('send_time', '10:00'), 'smtp': '%s:%s' % (CFG['smtp']['host'], CFG['smtp']['port']), 'leave': LEAVE_INFO, 'punch': IMPORT_INFO, 'log': [dict(r) for r in c.execute('SELECT * FROM email_log ORDER BY id DESC LIMIT 50')]})
        self.send_response(404); self.end_headers()
    def do_POST(self):
        if not self.ok() or not self.adm(): return
        raw = self.rfile.read(int(self.headers.get('Content-Length', 0))); p = self.path
        if p == '/api/leave':
            try: return self.out({'count': sync_leave(raw, self.headers.get('X-Filename', 'x.xlsx'))})
            except Exception as e: return self.out({'error': 'Could not read file: %s' % e})
        j = json.loads(raw or b'{}')
        with LOCK, db() as c:
            if p == '/api/punches':
                before = c.total_changes
                c.executemany('INSERT OR IGNORE INTO punches(emp,ts) VALUES(?,?)', [(str(r[0]), r[2]) for r in j['rows']])
                added = c.total_changes - before
                c.executemany('INSERT INTO employees(id,name) VALUES(?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name', {(str(r[0]), r[1]) for r in j['rows']})
                return self.out({'added': added})
            if p == '/api/late': c.execute("INSERT OR REPLACE INTO settings VALUES('late',?)", (j['late'],)); return self.out({})
            if p == '/api/clear': [c.execute('DELETE FROM ' + t) for t in ('punches', 'employees')]; return self.out({})
        if p == '/api/send': ok, msg = send(j['date'], True); return self.out({'ok': ok, 'message': msg})
        self.send_response(404); self.end_headers()

if __name__ == '__main__':
    watch(); refresh_leave()
    threading.Thread(target=scheduler, daemon=True).start()
    print('Attendance server on http://%s:%s  (Ctrl+C to stop)' % (CFG.get('host', '0.0.0.0'), CFG.get('port', 8080)))
    ThreadingHTTPServer((CFG.get('host', '0.0.0.0'), CFG.get('port', 8080)), H).serve_forever()
