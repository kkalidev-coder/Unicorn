@echo off
title Attendance Server
cd /d "%~dp0"

rem --- find Python (py launcher or python) ---
set "PY="
where py >nul 2>nul && set "PY=py"
if not defined PY where python >nul 2>nul && set "PY=python"
if not defined PY (
  echo Python was not found. Please install Python 3.8 or newer from python.org
  echo and tick "Add Python to PATH" during setup.
  pause
  exit /b 1
)

rem --- read port from config.json (default 8080) ---
set "PORT=8080"
for /f %%p in ('powershell -NoProfile -Command "(Get-Content config.json -Raw | ConvertFrom-Json).port" 2^>nul') do set "PORT=%%p"

echo ============================================
echo   Attendance Server  -  http://localhost:%PORT%
echo   Keep this window open. Close it to stop.
echo ============================================

rem --- open the app in the default browser after 3 seconds ---
start "" /min cmd /c "timeout /t 3 >nul & start http://localhost:%PORT%"

rem --- run the server; restart automatically if it stops unexpectedly ---
:run
%PY% attendance_server.py
echo.
echo Server stopped. Restarting in 5 seconds... (press Ctrl+C to quit)
timeout /t 5 >nul
goto run
