# Unicorn AI Recon — standalone (on-premise) version

Same bonus-scheme reconciliation tool, running entirely on your own machine
with a local SQLite database (`unicorn_recon.db`). No internet connection
needed after setup, and nothing is ever sent to Anthropic or anywhere else.

## What's stored where
- **Bonus schemes** and the **exception log** (mismatch / not issued /
  over-issued / extrapolated lines) are saved permanently in
  `unicorn_recon.db`, right next to `app.py`.
- Your **sales file** is never uploaded anywhere — it's parsed in the
  browser each time, same as before, and only the flagged exception rows
  get written to the database.

## Requirements
- Python 3.9 or newer
- pip

## Setup (one time)

```bash
cd unicorn-recon-app
python3 -m venv venv

# macOS / Linux
source venv/bin/activate
# Windows (PowerShell)
venv\Scripts\Activate.ps1

pip install -r requirements.txt
```

## Run

```bash
python app.py
```

Then open **http://127.0.0.1:5000** in your browser. Leave the terminal
window open while you use it — closing it stops the server.

To stop the server, press `Ctrl+C` in that terminal.

## Day-to-day use
Nothing changes from before:
1. Bonus schemes tab → upload `Bonus_Items.xlsx` (saved automatically to SQLite).
2. Sales lines tab → upload your daily/weekly posted sales export.
3. Reconciliation tab → review, filter, Export CSV/Excel.
4. Exception log tab → full permanent history, filterable by status, plus
   an **Export SQL** button for a portable `.sql` snapshot any time you
   want to archive or move the data.

## Backing up / moving the database
The entire database is the single file `unicorn_recon.db`. To back it up,
just copy that file elsewhere. To move the app to another machine, copy
the whole `unicorn-recon-app` folder (including that file) and repeat the
Setup steps there.

## Inspecting the database directly
Any SQLite tool works, e.g.:

```bash
sqlite3 unicorn_recon.db
sqlite> .tables
sqlite> SELECT * FROM exceptions ORDER BY id DESC LIMIT 20;
```

## Troubleshooting
- **"Address already in use"** — something else is using port 5000. Edit
  the last line of `app.py` and change `port=5000` to e.g. `port=5050`,
  then open `http://127.0.0.1:5050` instead.
- **Excel parsing library not loading** — the page loads the spreadsheet
  parser from a CDN (`cdnjs.cloudflare.com`) the first time you open it,
  so you'll need internet access at least once (or swap it for a local
  copy of SheetJS in `templates/index.html` if you need fully offline
  setup from the start).
