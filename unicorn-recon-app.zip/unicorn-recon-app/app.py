"""
Unicorn AI Recon — standalone local app
----------------------------------------
Serves the reconciliation UI and stores bonus schemes + the exception log
in a local SQLite file (unicorn_recon.db) next to this script. Nothing is
sent anywhere outside this machine.

Run:
    pip install -r requirements.txt
    python app.py
Then open:
    http://127.0.0.1:5000
"""
import json
import sqlite3
from contextlib import closing
from pathlib import Path

from flask import Flask, g, jsonify, render_template, request

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "unicorn_recon.db"

app = Flask(__name__)


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    with closing(sqlite3.connect(DB_PATH)) as db:
        db.executescript(
            """
            CREATE TABLE IF NOT EXISTS schemes (
                id TEXT PRIMARY KEY,
                data TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS batches (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                file_name TEXT,
                imported_at TEXT,
                total_lines INTEGER,
                exception_count INTEGER
            );
            CREATE TABLE IF NOT EXISTS exceptions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                batch_id INTEGER NOT NULL REFERENCES batches(id) ON DELETE CASCADE,
                date TEXT, doc_no TEXT, customer TEXT, item TEXT, item_desc TEXT,
                qty REAL, tier TEXT, bonus_item TEXT,
                expected REAL, actual REAL, status TEXT
            );
            """
        )
        db.commit()


@app.route("/")
def index():
    return render_template("index.html")


# ---------- Bonus schemes: stored as one row per rule, keyed by client id ----------

@app.route("/api/schemes", methods=["GET"])
def get_schemes():
    db = get_db()
    rows = db.execute("SELECT data FROM schemes").fetchall()
    return jsonify([json.loads(r["data"]) for r in rows])


@app.route("/api/schemes", methods=["PUT"])
def put_schemes():
    """Client sends the full current list; we replace the table with it."""
    schemes = request.get_json(force=True) or []
    db = get_db()
    db.execute("DELETE FROM schemes")
    for s in schemes:
        sid = s.get("id") or s.get("mainItem", "") + "-" + s.get("bonusItem", "")
        db.execute("INSERT OR REPLACE INTO schemes (id, data) VALUES (?, ?)", (sid, json.dumps(s)))
    db.commit()
    return jsonify({"ok": True, "count": len(schemes)})


# ---------- Exception log ----------

@app.route("/api/exceptions", methods=["POST"])
def add_batch():
    batch = request.get_json(force=True) or {}
    db = get_db()
    cur = db.execute(
        "INSERT INTO batches (file_name, imported_at, total_lines, exception_count) VALUES (?, ?, ?, ?)",
        (batch.get("fileName"), batch.get("importedAt"), batch.get("totalLines"), batch.get("exceptionCount")),
    )
    batch_id = cur.lastrowid
    for e in batch.get("exceptions", []):
        db.execute(
            """INSERT INTO exceptions
               (batch_id, date, doc_no, customer, item, item_desc, qty, tier, bonus_item, expected, actual, status)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (batch_id, e.get("date"), e.get("docNo"), e.get("customer"), e.get("item"), e.get("itemDesc"),
             e.get("qty"), e.get("tier"), e.get("bonusItem"), e.get("expected"), e.get("actual"), e.get("status")),
        )
    db.commit()
    return jsonify({"ok": True, "batchId": batch_id})


@app.route("/api/exceptions", methods=["GET"])
def list_batches():
    db = get_db()
    batches = db.execute(
        "SELECT * FROM batches ORDER BY imported_at DESC LIMIT 50"
    ).fetchall()
    out = []
    for b in batches:
        rows = db.execute(
            "SELECT * FROM exceptions WHERE batch_id = ?", (b["id"],)
        ).fetchall()
        out.append({
            "fileName": b["file_name"],
            "importedAt": b["imported_at"],
            "totalLines": b["total_lines"],
            "exceptionCount": b["exception_count"],
            "exceptions": [
                {
                    "date": r["date"], "docNo": r["doc_no"], "customer": r["customer"],
                    "item": r["item"], "itemDesc": r["item_desc"], "qty": r["qty"],
                    "tier": r["tier"], "bonusItem": r["bonus_item"],
                    "expected": r["expected"], "actual": r["actual"], "status": r["status"],
                }
                for r in rows
            ],
        })
    return jsonify(out)


if __name__ == "__main__":
    init_db()
    app.run(host="127.0.0.1", port=5000, debug=True)
